package com.example.cutter

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts.*
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.*
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.*
import androidx.media3.transformer.Composition
import androidx.media3.ui.PlayerView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.delay
import java.io.File

// 50 languages: English & Hindi built-in, others translated on-device by ML Kit (one-time pack download)
val L = listOf(
    "English" to "en",
    "हिन्दी" to "hi",
    "Español" to "es",
    "Français" to "fr",
    "العربية" to "ar",
    "বাংলা" to "bn",
    "اردو" to "ur",
    "Português" to "pt",
    "Русский" to "ru",
    "Deutsch" to "de",
    "日本語" to "ja",
    "中文" to "zh",
    "한국어" to "ko",
    "Italiano" to "it",
    "Türkçe" to "tr",
    "Tiếng Việt" to "vi",
    "ไทย" to "th",
    "Bahasa Indonesia" to "id",
    "Bahasa Melayu" to "ms",
    "Nederlands" to "nl",
    "Polski" to "pl",
    "Українська" to "uk",
    "Română" to "ro",
    "Ελληνικά" to "el",
    "Čeština" to "cs",
    "Svenska" to "sv",
    "Magyar" to "hu",
    "Suomi" to "fi",
    "Dansk" to "da",
    "Norsk" to "no",
    "עברית" to "he",
    "فارسی" to "fa",
    "ગુજરાતી" to "gu",
    "मराठी" to "mr",
    "தமிழ்" to "ta",
    "తెలుగు" to "te",
    "ಕನ್ನಡ" to "kn",
    "Kiswahili" to "sw",
    "Filipino" to "tl",
    "Български" to "bg",
    "Hrvatski" to "hr",
    "Slovenčina" to "sk",
    "Català" to "ca",
    "Afrikaans" to "af",
    "Shqip" to "sq",
    "ქართული" to "ka",
    "Eesti" to "et",
    "Lietuvių" to "lt",
    "Latviešu" to "lv",
    "Íslenska" to "is"
)
val RTL = setOf("ar", "ur", "he", "fa")
val EN = "Cut|Join|Settings|Choose audio / video|Choose multiple files|Quality|Original|Preview selection|Start|End|Cut & Save (keep selected parts)|Cut & Delete (remove selected parts)|Join & Save|Extract audio (M4A)|Processing|Saved ✅|Error|Share|Language|Nothing would be left|Total|Cancel|New project|Cancelled|Select Save folder/location|Add this part|Selected parts|Clear all|Seek moves|Set here|Downloading language pack (internet needed once)…|Translation failed. Check internet.|Add parts with ➕ — or cut the current selection directly|Now".split("|")
val HI = "काटें|जोड़ें|सेटिंग्स|ऑडियो / वीडियो चुनें|कई फाइलें चुनें|क्वालिटी|ओरिजिनल|चुना हिस्सा प्रीव्यू करें|शुरू|अंत|कट एंड सेव (चुने हिस्से रखें)|कट एंड डिलीट (चुने हिस्से हटाएँ)|जोड़ें और सेव करें|ऑडियो निकालें (M4A)|प्रोसेसिंग|सेव हो गया ✅|त्रुटि|शेयर करें|भाषा|कुछ नहीं बचेगा|कुल|रद्द करें|नया प्रोजेक्ट|रद्द किया गया|सेव फोल्डर/लोकेशन चुनें|यह हिस्सा जोड़ें|चुने हुए हिस्से|सब हटाएँ|सीक से बदलेगा|यहाँ सेट करें|भाषा पैक डाउनलोड हो रहा है (एक बार इंटरनेट चाहिए)…|अनुवाद विफल। इंटरनेट जाँचें।|➕ से हिस्से जोड़ें — या सीधे मौजूदा चयन काटें|अभी".split("|")

fun translateAll(code: String, src: List<String>, ok: (List<String>) -> Unit, fail: () -> Unit) {
    val tr = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage("en").setTargetLanguage(code).build())
    tr.downloadModelIfNeeded(DownloadConditions.Builder().build()).addOnSuccessListener {
        val out = src.toMutableList(); var left = src.size
        src.forEachIndexed { i, s ->
            tr.translate(s).addOnSuccessListener { r -> out[i] = r }
                .addOnCompleteListener { left--; if (left == 0) { tr.close(); ok(out) } }
        }
    }.addOnFailureListener { tr.close(); fail() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Color(0xFF5B8DEF), secondary = Color(0xFF7ED6C1),
                background = Color(0xFFF6F9FF), surface = Color.White)) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
}

data class MInfo(val dur: Long, val video: Boolean, val w: Int, val h: Int, val br: Int)

fun info(c: Context, u: Uri): MInfo {
    val r = MediaMetadataRetriever(); r.setDataSource(c, u)
    fun g(k: Int) = r.extractMetadata(k)
    var w = g(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
    var h = g(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
    val rot = g(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
    if (rot == 90 || rot == 270) { val x = w; w = h; h = x }
    val i = MInfo(g(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L,
        g(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes", w, h,
        g(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0)
    r.release(); return i
}

// output size for chosen quality (null = keep original / never upscale)
fun target(i: MInfo, res: Int): Pair<Int, Int>? {
    if (res == 0 || !i.video || i.w == 0) return null
    val short = minOf(i.w, i.h)
    if (res >= short) return null
    val s = res.toFloat() / short
    fun ev(x: Float) = (Math.round(x / 2f) * 2).coerceAtLeast(2)
    return ev(i.w * s) to ev(i.h * s)
}

// keep source bitrate for Original (no quality loss); presets never exceed the source
fun bitrateFor(i: MInfo, res: Int): Int {
    val src = if (i.br > 0) (i.br * 0.92).toInt() else 8_000_000
    val preset = mapOf(240 to 600_000, 360 to 1_000_000, 480 to 1_800_000, 720 to 3_500_000, 1080 to 7_000_000)[res]
    return (if (preset == null) src else minOf(src, preset)).coerceAtLeast(500_000)
}

fun fmt(ms: Long): String {
    val s = ms / 1000; val h = s / 3600
    return if (h > 0) "%d:%02d:%02d".format(h, s / 60 % 60, s % 60) else "%02d:%02d".format(s / 60, s % 60)
}

fun parse(s: String): Long? {
    val p = s.trim().split(":").map { it.toLongOrNull() ?: return null }
    if (p.size !in 1..3) return null
    return p.fold(0L) { a, b -> a * 60 + b } * 1000
}

fun nameOf(c: Context, u: Uri): String {
    val n = try {
        c.contentResolver.query(u, null, null, null, null)?.use {
            if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        }?.substringBeforeLast('.')
    } catch (e: Exception) { null }
    return n ?: "media"
}

fun merge(p: List<LongRange>): List<LongRange> {
    val o = mutableListOf<LongRange>()
    for (r in p.sortedBy { it.first }) {
        if (o.isNotEmpty() && r.first <= o.last().last) o[o.size - 1] = o.last().first..maxOf(o.last().last, r.last) else o += r
    }
    return o
}

fun invert(p: List<LongRange>, dur: Long): List<LongRange> {
    var c = 0L; val o = mutableListOf<LongRange>()
    for (r in merge(p)) { if (r.first > c + 200) o += c..r.first; c = maxOf(c, r.last) }
    if (dur > c + 200) o += c..dur
    return o
}

fun clip(u: Uri, s: Long, e: Long, video: Boolean, tgt: Pair<Int, Int>?): EditedMediaItem {
    val mi = MediaItem.Builder().setUri(u).setClippingConfiguration(
        MediaItem.ClippingConfiguration.Builder().setStartPositionMs(s).setEndPositionMs(e).build()).build()
    val fx = if (video && tgt != null)
        listOf<Effect>(Presentation.createForWidthAndHeight(tgt.first, tgt.second, Presentation.LAYOUT_SCALE_TO_FIT)) else listOf()
    return EditedMediaItem.Builder(mi).setRemoveVideo(!video).setEffects(Effects(listOf(), fx)).build()
}

fun export(ctx: Context, items: List<EditedMediaItem>, video: Boolean, folder: Uri?, base: String,
           bitrate: Int, trim: Boolean, hold: (Transformer) -> Unit, done: (Boolean, Uri?, String) -> Unit) {
    val ext = if (video) "mp4" else "m4a"
    val mime = if (video) "video/mp4" else "audio/mp4"
    val tmp = File(ctx.cacheDir, "t${System.currentTimeMillis()}.$ext")
    val b = Transformer.Builder(ctx).setAudioMimeType(MimeTypes.AUDIO_AAC)
    if (video) b.setEncoderFactory(DefaultEncoderFactory.Builder(ctx)
        .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
        .setEnableFallback(true).build())
    if (trim) try { // fast, lossless cut (re-encodes only the first frames) when supported
        Transformer.Builder::class.java.getMethod("experimentalSetTrimOptimizationEnabled", java.lang.Boolean.TYPE).invoke(b, true)
    } catch (e: Exception) { }
    val t = b.addListener(object : Transformer.Listener {
        override fun onCompleted(c: Composition, r: ExportResult) {
            try {
                val uri: Uri = if (folder != null)
                    DocumentFile.fromTreeUri(ctx, folder)!!.createFile(mime, base)!!.uri
                else ctx.contentResolver.insert(
                    if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, "$base.$ext")
                        put(MediaStore.MediaColumns.MIME_TYPE, mime)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, (if (video) "Movies" else "Music") + "/SimpleCutter")
                    })!!
                ctx.contentResolver.openOutputStream(uri)!!.use { o -> tmp.inputStream().use { it.copyTo(o) } }
                tmp.delete(); done(true, uri, "")
            } catch (e: Exception) { done(false, null, e.message ?: "") }
        }
        override fun onError(c: Composition, r: ExportResult, e: ExportException) { done(false, null, e.message ?: "") }
    }).build()
    hold(t)
    if (items.size == 1) t.start(items[0], tmp.absolutePath)
    else t.start(Composition.Builder(listOf(EditedMediaItemSequence(items))).build(), tmp.absolutePath)
}

@Composable
fun TimeField(label: String, v: Long, ver: Int, mod: Modifier, onSet: (Long) -> Unit) {
    var txt by remember(ver) { mutableStateOf(fmt(v)) }
    OutlinedTextField(txt, { txt = it; parse(it)?.let(onSet) }, label = { Text(label) }, singleLine = true, modifier = mod)
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val view = LocalView.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    var lang by remember { mutableStateOf(prefs.getInt("lang", 0).coerceIn(0, L.size - 1)) }
    var strs by remember {
        val code = L[lang].second
        mutableStateOf(when (code) {
            "en" -> EN
            "hi" -> HI
            else -> prefs.getString("tr_$code", null)?.split("\u0001")?.takeIf { it.size == EN.size } ?: EN
        })
    }
    fun t(i: Int) = strs.getOrElse(i) { EN[i] }
    var langMsg by remember { mutableStateOf("") }
    var translating by remember { mutableStateOf(false) }

    var tab by remember { mutableStateOf(0) }
    var folder by remember { mutableStateOf<Uri?>(null) }
    var res by remember { mutableStateOf(0) } // 0 = original
    var busy by remember { mutableStateOf(false) }
    var sec by remember { mutableStateOf(0L) }
    var pct by remember { mutableStateOf(0f) }
    var tr by remember { mutableStateOf<Transformer?>(null) }
    var msg by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf<Uri?>(null) }
    var file by remember { mutableStateOf<Uri?>(null) }
    var inf by remember { mutableStateOf<MInfo?>(null) }
    var dur by remember { mutableStateOf(0L) }
    var isVideo by remember { mutableStateOf(true) }
    var startMs by remember { mutableStateOf(0L) }
    var endMs by remember { mutableStateOf(0L) }
    var edge by remember { mutableStateOf(0) } // which point the player seek moves: 0 start, 1 end
    var ver by remember { mutableStateOf(0) }
    var parts by remember { mutableStateOf(listOf<LongRange>()) }
    var files by remember { mutableStateOf(listOf<Uri>()) }
    var pos by remember { mutableStateOf(0L) }
    var previewing by remember { mutableStateOf(false) }
    var langMenu by remember { mutableStateOf(false) }

    val guard = remember { LongArray(1) }
    val exo = remember {
        ExoPlayer.Builder(ctx).setSeekBackIncrementMs(5000).setSeekForwardIncrementMs(5000).build()
    }
    fun seek(p: Long) { guard[0] = System.currentTimeMillis() + 500; exo.seekTo(p) }
    // any seek on the player (5s buttons, scrubbing) moves the selected point + slider + time box
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onPositionDiscontinuity(o: Player.PositionInfo, n: Player.PositionInfo, r: Int) {
                if (r != Player.DISCONTINUITY_REASON_SEEK || System.currentTimeMillis() < guard[0]) return
                val p = n.positionMs
                if (edge == 0) startMs = p.coerceIn(0L, maxOf(0L, endMs - 500)) else endMs = p.coerceIn(startMs + 500, maxOf(startMs + 500, dur))
                ver++
            }
        }
        exo.addListener(l)
        onDispose { exo.removeListener(l); exo.release() }
    }
    LaunchedEffect(Unit) {
        while (true) {
            pos = exo.currentPosition
            if (previewing && pos >= endMs) { exo.pause(); previewing = false }
            delay(250)
        }
    }
    LaunchedEffect(busy) {
        view.keepScreenOn = busy
        val t0 = System.currentTimeMillis()
        while (busy) {
            sec = (System.currentTimeMillis() - t0) / 1000
            val h = ProgressHolder()
            if (tr?.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) pct = h.progress / 100f
            delay(300)
        }
    }

    val pickOne = rememberLauncherForActivityResult(OpenDocument()) { u ->
        if (u != null) {
            val i = info(ctx, u)
            file = u; inf = i; dur = i.dur; isVideo = i.video; startMs = 0; endMs = i.dur; ver++
            parts = listOf(); msg = ""; saved = null; previewing = false; edge = 0
            exo.setMediaItem(MediaItem.fromUri(u)); exo.prepare()
        }
    }
    val pickMany = rememberLauncherForActivityResult(OpenMultipleDocuments()) { files = it }
    val pickDir = rememberLauncherForActivityResult(OpenDocumentTree()) { u ->
        if (u != null) { ctx.contentResolver.takePersistableUriPermission(u, 3); folder = u }
    }
    fun go(items: List<EditedMediaItem>, video: Boolean, base: String, br: Int, trim: Boolean) {
        busy = true; pct = 0f; msg = ""; saved = null
        export(ctx, items, video, folder, base, br, trim, { tr = it }) { ok, u, e ->
            busy = false
            if (ok) { saved = u; msg = t(15) } else msg = t(16) + ": " + e
        }
    }
    fun runCut(segs: List<LongRange>, base: String) {
        val i = inf ?: return
        if (segs.isEmpty()) { msg = t(19); return }
        exo.pause(); previewing = false
        val tgt = if (isVideo) target(i, res) else null
        go(segs.map { clip(file!!, it.first, it.last, isVideo, tgt) }, isVideo, base, bitrateFor(i, res),
            segs.size == 1 && tgt == null && isVideo)
    }
    fun newProject() {
        exo.stop(); exo.clearMediaItems()
        file = null; inf = null; files = listOf(); parts = listOf(); saved = null; msg = ""; pct = 0f
        dur = 0; startMs = 0; endMs = 0; previewing = false; ver++
    }
    fun pickLang(i: Int) {
        val code = L[i].second
        fun setLang(s: List<String>) { strs = s; lang = i; prefs.edit().putInt("lang", i).apply() }
        when (code) {
            "en" -> setLang(EN)
            "hi" -> setLang(HI)
            else -> {
                val c = prefs.getString("tr_$code", null)?.split("\u0001")?.takeIf { it.size == EN.size }
                if (c != null) setLang(c) else {
                    translating = true; langMsg = t(30)
                    translateAll(code, EN, { r ->
                        prefs.edit().putString("tr_$code", r.joinToString("\u0001")).apply()
                        setLang(r); translating = false; langMsg = ""
                    }, { translating = false; langMsg = t(31) })
                }
            }
        }
    }

    // scissors spin once on app open / resume / rotation
    val rot = remember { Animatable(0f) }
    var resumes by remember { mutableStateOf(0) }
    val orient = LocalConfiguration.current.orientation
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) resumes++ }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }
    LaunchedEffect(orient, resumes) { rot.snapTo(0f); rot.animateTo(360f, tween(900)) }

    CompositionLocalProvider(LocalLayoutDirection provides if (L[lang].second in RTL) LayoutDirection.Rtl else LayoutDirection.Ltr) {
    Column(Modifier.fillMaxSize()) {
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("✂️", fontSize = 30.sp, modifier = Modifier.graphicsLayer { rotationZ = rot.value })
            Text("  Simple Cutter", style = MaterialTheme.typography.headlineSmall)
        }
        TabRow(tab, containerColor = Color.Transparent) {
            Tab(tab == 0, { tab = 0 }, text = { Text(t(0)) })
            Tab(tab == 1, { tab = 1 }, text = { Text(t(1)) })
            Tab(tab == 2, { tab = 2 }, text = { Text(t(2)) })
        }
        if (tab == 2) {
            Text(t(18))
            Box {
                OutlinedButton({ langMenu = true }, enabled = !translating) { Text("🌐 ${L[lang].first}  ▾") }
                DropdownMenu(langMenu, { langMenu = false }) {
                    L.forEachIndexed { i, p ->
                        DropdownMenuItem({ Text(p.first) }, { langMenu = false; pickLang(i) })
                    }
                }
            }
            if (translating) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 3.dp)
                Text(langMsg, style = MaterialTheme.typography.bodySmall)
            } else if (langMsg.isNotEmpty()) Text(langMsg, style = MaterialTheme.typography.bodySmall)
        } else {
            if (tab == 1 || isVideo) Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(t(5))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0, 240, 360, 480, 720, 1080).forEach {
                            FilterChip(res == it, { res = it }, label = { Text(if (it == 0) t(6) else "${it}p") })
                        }
                    }
                }
            }
            if (tab == 0) {
                Button({ pickOne.launch(arrayOf("video/*", "audio/*")) }) { Text(t(3)) }
                if (file != null && dur > 0) {
                    AndroidView({ PlayerView(it).apply { player = exo; useController = true } },
                        Modifier.fillMaxWidth().height(210.dp))
                    Text("${t(33)} ${fmt(pos)}  •  ${t(20)} ${fmt(dur)}")
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(t(28) + ":")
                        FilterChip(edge == 0, { edge = 0; seek(startMs) }, label = { Text(t(8)) })
                        FilterChip(edge == 1, { edge = 1; seek(endMs) }, label = { Text(t(9)) })
                        OutlinedButton({ val p = exo.currentPosition
                            if (edge == 0) startMs = p.coerceIn(0L, maxOf(0L, endMs - 500)) else endMs = p.coerceIn(startMs + 500, maxOf(startMs + 500, dur))
                            ver++ }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("📍 " + t(29)) }
                    }
                    Text("${fmt(startMs)} — ${fmt(endMs)}")
                    RangeSlider(startMs.toFloat()..endMs.toFloat(), { r ->
                        val ns = r.start.toLong(); val ne = r.endInclusive.toLong()
                        if (ns != startMs) { edge = 0; seek(ns) } else if (ne != endMs) { edge = 1; seek(ne) }
                        startMs = ns; endMs = ne; ver++
                    }, valueRange = 0f..dur.toFloat())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TimeField(t(8), startMs, ver, Modifier.weight(1f)) { startMs = it.coerceIn(0L, maxOf(0L, endMs - 500)) }
                        TimeField(t(9), endMs, ver, Modifier.weight(1f)) { endMs = it.coerceIn(startMs + 500, maxOf(startMs + 500, dur)) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton({ seek(startMs); exo.play(); previewing = true }) { Text("▶ " + t(7)) }
                        Button({ parts = parts + listOf(startMs..endMs) }) { Text("➕ " + t(25)) }
                    }
                    if (parts.isNotEmpty()) {
                        Text(t(26))
                        parts.forEachIndexed { i, r ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("${i + 1}.  ${fmt(r.first)} — ${fmt(r.last)}", Modifier.weight(1f))
                                TextButton({ parts = parts.filterIndexed { j, _ -> j != i } }) { Text("✖") }
                            }
                        }
                        TextButton({ parts = listOf() }) { Text(t(27)) }
                    } else Text(t(32), style = MaterialTheme.typography.bodySmall)
                    val eff = if (parts.isEmpty()) listOf(startMs..endMs) else parts
                    val base = nameOf(ctx, file!!)
                    Button({ runCut(merge(eff), base + "_cut") }, enabled = !busy,
                        modifier = Modifier.fillMaxWidth()) { Text(t(10)) }
                    Button({ runCut(invert(eff, dur), base + "_edit") }, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) { Text(t(11)) }
                    if (isVideo) OutlinedButton({
                        go(merge(eff).map { clip(file!!, it.first, it.last, false, null) }, false, base + "_audio", 0, false)
                    }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("🎵 " + t(13)) }
                }
            } else {
                Button({ pickMany.launch(arrayOf("video/*", "audio/*")) }) { Text(t(4)) }
                files.forEachIndexed { i, u -> Text("${i + 1}. ${nameOf(ctx, u)}", maxLines = 1) }
                if (files.size >= 2) Button({
                    val infs = files.map { info(ctx, it) }
                    val v = infs[0].video
                    val tgt = if (v) target(infs[0], res) else null
                    go(files.mapIndexed { i, u -> clip(u, 0, infs[i].dur, v, tgt ?: if (v) infs[0].w to infs[0].h else null) },
                        v, "joined_${System.currentTimeMillis() / 1000}", bitrateFor(infs[0], res), false)
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(t(12)) }
            }
            if (busy) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
                    Text("${t(14)}... ${(pct * 100).toInt()}%  •  ${fmt(sec * 1000)}")
                }
                LinearProgressIndicator({ pct }, Modifier.fillMaxWidth())
                OutlinedButton({ tr?.cancel(); tr = null; busy = false; msg = t(23) }) { Text("✖ " + t(21)) }
            }
            if (msg.isNotEmpty()) Text(msg)
            if (!busy && (saved != null || msg.isNotEmpty())) Button({ newProject() }) { Text("➕ " + t(22)) }
        }
    }
    if (tab == 2) Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("App Developed by Suresh Vyas", style = MaterialTheme.typography.bodyMedium)
        Text("Bikaner, Rajasthan", style = MaterialTheme.typography.bodySmall)
    } else Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton({ pickDir.launch(null) }, Modifier.weight(1f)) {
            Text("📁 " + t(24) + if (folder != null) " ✓" else "")
        }
        Button({
            saved?.let { u ->
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = ctx.contentResolver.getType(u) ?: "*/*"
                    putExtra(Intent.EXTRA_STREAM, u); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                ctx.startActivity(Intent.createChooser(i, null))
            }
        }, enabled = saved != null,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E9E6B), contentColor = Color.White)) {
            Icon(Icons.Filled.Share, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text(t(17))
        }
    }
    }
    }
}
